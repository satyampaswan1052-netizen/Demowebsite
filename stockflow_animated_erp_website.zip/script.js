const $=s=>document.querySelector(s);
function openModal(id){$('#'+id).classList.add('show')}
function closeModals(){document.querySelectorAll('.modal').forEach(m=>m.classList.remove('show'))}
document.querySelectorAll('.modal').forEach(m=>m.addEventListener('click',e=>{if(e.target===m)closeModals()}));
function toast(msg){const t=$('#toast');t.textContent=msg;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),2400)}
function scrollToId(id){document.getElementById(id).scrollIntoView({behavior:'smooth'})}
function filterProducts(){
  const q=$('#search').value.toLowerCase(), cat=$('#category').value.toLowerCase();
  document.querySelectorAll('#productTable tbody tr').forEach(row=>{
    const text=(row.dataset.search||'')+' '+row.innerText.toLowerCase();
    row.style.display=(!q||text.includes(q)) && (!cat||text.includes(cat)) ? '' : 'none';
  });
}
function refreshDashboard(){
  document.querySelectorAll('.bars i').forEach((b,i)=>{b.style.height=(40+Math.random()*55)+'%'});
  toast('Live dashboard refreshed');
}
$('#themeBtn').addEventListener('click',()=>{document.body.classList.toggle('light');$('#themeBtn').textContent=document.body.classList.contains('light')?'☀':'☾'});
document.addEventListener('keydown',e=>{if(e.key==='Escape')closeModals()});
